package io.operation;
class Dog
{
	int i=10;
	int j=20;
}
public class Serilization1 {
public static void main(String[]args)
{
	Dog D= new Dog();
	System.out.println("Serilization is started");
	
	
	
	
	
	System.out.println("Serilization is ended");
}
}
