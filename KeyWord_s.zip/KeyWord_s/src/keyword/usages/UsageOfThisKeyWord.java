package keyword.usages;

class Add{
	int i=0;
	public void setAdd(int i)
	{
		this.
	    i=i;
	}
	public void Sysout() {
	  System.out.println(i);
	}
}
public class UsageOfThisKeyWord {
public static void main(String[] args)
{
 Add ad= new Add();
 ad.setAdd(1);
 ad.Sysout();
}
}
