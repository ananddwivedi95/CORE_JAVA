package eight.version;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@interface CricketPlayer
{
	/*
	 * int Total_Score() default 20000; String Player_Name() default "Anan";
	 */
	int Total_Score();
	String Player_Name();
}
@CricketPlayer(Total_Score=20000,Player_Name="anan")
class ViratKohali
{   
  
	private String Country;
    private int inning;
	
	public String getCountry() {
		return Country;
	}
	
	public int getInning() {
		return inning;
	}
	
	public void setCountry(String country) {
		this.Country = country;
	}
	
	public void setInning(int inning) {
		this.inning = inning;
	}
	
}
public class LaunchAnnotation {
public static void main(String[] args)
{
	 ViratKohali VL= new ViratKohali();
	 VL.setInning(2000000);
	 VL.setCountry("india");
	 System.out.println(VL.getCountry());
	 System.out.println(VL.getInning());
	 System.out.println(VL.getClass());
	 
	 
	 //method to print or get the value of Annnotation (it is the reflection api(APPILICATION PROGRAMMING INTERFACE ) which is used for get the value of annotation 
	 Class c=VL.getClass();
	 Annotation an=c.getAnnotation(CricketPlayer.class);
	 CricketPlayer cp=(CricketPlayer) an;
	 int rn=cp.Total_Score();
	 String cn=cp.Player_Name();
	 
	 
	 System.out.println(rn);
	 System.out.println(cn);
}
}
