package eight.version;
interface Dog
{
	public abstract  String dog(String name);
	
	  public static void dog1(String name)
	  { 
		  System.out.println(name); 
	    } 
	  public default void dogVoice() 
	  { 
		  System.out.println("bhaww");
	  }	
}
public  class ImplementationOfInterface implements Dog{
public static void main(String[] args)
{
	Dog D= new ImplementationOfInterface();
	System.out.println(D.dog("bantu"));
	D.dogVoice();
	Dog.dog1("anshu");
	
}

@Override
public String dog(String name) {
		return name;
}
}
