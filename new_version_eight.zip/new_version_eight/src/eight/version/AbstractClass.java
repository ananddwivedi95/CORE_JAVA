package eight.version;
abstract class Hello
{
	abstract void hello();
	void say()
	{
		System.out.println("hello");
	}
}
public class AbstractClass extends Hello  {
public static void main(String[] args)
{
	
     AbstractClass ab= new AbstractClass();
     
	ab.hello();
	ab.say();
}

@Override
void hello() {
	System.out.println("hello");
	
}
}
