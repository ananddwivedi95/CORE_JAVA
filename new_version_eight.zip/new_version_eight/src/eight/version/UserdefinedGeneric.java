package eight.version;

class AccountOpen<T>
{
	T obj;
	AccountOpen(T obj)
	{
		this.obj=obj;
	}
	public void show()
	{
		System.out.println("The type of object is "+obj+"  "+obj.getClass().getName());
	}
	
}
public class UserdefinedGeneric {
public static void main(String[] args)
{
	AccountOpen<Integer> gold=new AccountOpen<Integer>(10);
	AccountOpen<String> platinum= new AccountOpen<String>("anan");
	AccountOpen<Double> silver= new AccountOpen<Double>(52.8);
	
	gold.show();
	platinum.show();
	silver.show();
}
}
