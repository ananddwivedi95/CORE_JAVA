package eight.version;
@FunctionalInterface
interface Calci
{
   public abstract int additionNum(int a,int b);
}
public class ImplemantationAnonomusClassB {
public static void main(String[] args)
{
    Calci CC= new Calci() {

		@Override
		public  int additionNum(int a, int b) {
			// TODO Auto-generated method stub
			return a+b;
		}
  
    };
    System.out.println(CC.additionNum(4, 5));
    
}
}
