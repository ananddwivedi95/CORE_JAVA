package eight.version;

import java.util.ArrayList;

public class UserDefindGenrics1 {
public static void main(String args[])
{
	ArrayList<String> al= new ArrayList<String>();
	al.add("anand");
	al.add("anshika");
	m1(al);
	ArrayList<Integer> al1= new ArrayList<Integer>();
	al1.add(1558);
	al1.add(2000000000);
	m2(al1);
	ArrayList al2= new ArrayList<String>();
	al2.add("anand");
	al2.add(143);
	al2.add("anshika");
	al2.add(true);
	//Object obj =m3(al2);
	System.out.println(m3(al2));
	
}
public static void m1(ArrayList<String> al)
{
	System.out.println(al);
}
public static void m2(ArrayList<Integer>  al1)
{
	System.out.println(al1);
}
static ArrayList m3(ArrayList al2)
{
	System.out.println(al2);
	return al2;
}
}
