package eight.version;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE) // it tells about what type of Target set or for which type is used for it . or it is used for which target it is used for class interface methods and verible
@Retention(RetentionPolicy.RUNTIME)  // it tells about how long its information will be pass
@interface StudentCollegeDetail
{
	String College_Name() default "United Institute Of Technology"; // here default keyword is used for give the body method as a vaue of vafiabke
	String College_Year() default "2026";
}
@StudentCollegeDetail
class Student
{
  public static  void show()
   {
	   System.out.println("Name : Anand Dwivedi");
   }
}
public class UserDefind1Annotation {
public static void main(String[] args)
{
	Student St= new Student();
	St.show();
	Class c=St.getClass();
	Annotation an=c.getAnnotation(StudentCollegeDetail.class);
	StudentCollegeDetail STDD=(StudentCollegeDetail) an;
	String College_Name=STDD.College_Name();
	String College_Year=STDD.College_Year();
	System.out.println("College : "+College_Name);
	System.out.println("Passout Year : "+College_Year);
}
}
