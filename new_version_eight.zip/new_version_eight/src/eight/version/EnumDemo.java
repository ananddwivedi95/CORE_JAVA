

package eight.version;
enum Result
{
	PASS, FAIL,RNF;
	Result()
	{
		System.out.println("Constructor called");
	}
}
enum Gender
{
	Male,FEMAIL;
}
enum Compass
{
	EAST, WESt,NORTH,SOUTH;
}
enum MONTH
{
	JAN,FAB,MAR,APR,MAY,JUN,JULY,AUG,SEP,OCT,NOV,DEC;
}
enum Month
{
	JAN,FAB,MAR,APR,MAY,JUN,JULY,AUG,SEP,OCT,NOV,DEC;
}
enum Course
{
	JAVA(25),JEE(320),SPRINGBOOT(80);
	private int courseid;
   private 	Course(int n)
	{
		courseid=n;
	}

	
	  void setCourdeid(int courseid) { this.courseid=courseid; }

	int getCourseid()
	{
		return courseid;
	}
}
public class EnumDemo {
	public static void main(String[] args)
	{
		
		/*
		 * Result res=Result.PASS; Result res1=Result.FAIL;
		 */
	/*
	 * System.out.println(res); System.out.println(res1);
	 */
		
		
		Course CC=Course(15);
		Course CC1=Course.JEE;
		Course CC2=Course.SPRINGBOOT;
		Course.JAVA.setCourdeid(10);
	   System.out.println(Course.SPRINGBOOT.getCourseid());
		int cse=Course.SPRINGBOOT.getCourseid();
		System.out.println(cse);
	}

	private static Course Course(int i) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
