package eight.version;
@FunctionalInterface
interface Calculator{
	public abstract int add(int a,int b);
}
public class ImplementataionOfInterfaceByLambdaExpression {
public static void main(String[] args)
{
	Calculator CC=(int a,int b)->{
	return a+b;	
	};
	System.out.println(CC.add(4, 5));
}

/*
 * @Override public int add(int a, int b) { // TODO Auto-generated method stub
 * return a+b; }
 * 
 * @Override public int sub(int a, int b) { // TODO Auto-generated method stub
 * return a-b; }
 */
}
